package com.softwarementors.extjs.djn.test.helper;

public class GenericTestObject<T> {
  public T value;
}
