DirectJNgine 
========================================================================

DirectJNgine is an Open Source library that provides a Java-based
implementation of the ExtJs Direct API.

You can go to http://extjs.com/blog/2009/05/13/introducing-ext-direct
in the ExtJs website for additional information.

Instructions
============
To start using DirectJNgine, read the documentation provided in the User's Guide.

License
============
This software is distributed under the terms of the GNU Lesser General 
Public License v3 (see the 'lgpl.txt' file for details).

Commercial use is permitted to the extent that the code/component(s)
do NOT become part of another Open Source or Commercially developed
licensed development library or toolkit without explicit permission.

This software uses the ExtJs library (http://extjs.com).
For information on the ExtJs license, see http://extjs.com/license).
